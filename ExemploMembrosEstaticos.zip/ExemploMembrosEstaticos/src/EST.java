
public class EST {
	private static int var = 100;
	private int var2 = 100;
	
	public static void mais() {
		var++;
	}
	public void menos() {
		var--;
	}
	public void prt() {
		System.out.println(var);
	}
	public static void prt(String a) {
		System.out.println(a);
	}
	public static void main(String[] args) {
		EST.mais();
		EST.prt("Teste de metodo estatico");
		EST a = new EST();
		a.prt();
		a.mais();
		a.prt();
		EST.mais();
		a.prt();
		
	}
}
