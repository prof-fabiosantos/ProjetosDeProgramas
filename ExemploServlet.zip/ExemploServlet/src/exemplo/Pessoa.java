package exemplo;

import java.io.*;
import javax.servlet.http.*;

public class Pessoa extends HttpServlet
{

    public Pessoa()
    {
    }

    public void doGet(HttpServletRequest req, HttpServletResponse res)
    {
        String nome = req.getParameter("nome");
        String sexo = req.getParameter("sexo");
        String profissao = req.getParameter("profissao");
        String banco = req.getParameter("banco");
        String programacao = req.getParameter("programacao");
        String redes = req.getParameter("redes");
        if(banco == null)
            banco = "";
        if(programacao == null)
            programacao = "";
        if(redes == null)
            redes = "";
        try
        {
            PrintWriter out = new PrintWriter(new FileWriter("c:/tmp/pessoa.txt"));
            out.println((new StringBuilder("Nome: ")).append(nome).toString());
            out.println((new StringBuilder("Sexo: ")).append(sexo).toString());
            out.println((new StringBuilder("Profissao: ")).append(profissao).toString());
            out.println("\301reas de interesse: ");
            String areas = "";
            if(!banco.equals(""))
                areas = (new StringBuilder(String.valueOf(areas))).append("Banco de Dados, ").toString();
            if(!programacao.equals(""))
                areas = (new StringBuilder(String.valueOf(areas))).append("Programa\347\343o de Computadores, ").toString();
            if(!redes.equals(""))
                areas = (new StringBuilder(String.valueOf(areas))).append("Redes de Computadores, ").toString();
            out.close();
            PrintStream tela = new PrintStream(res.getOutputStream());
            tela.println("<html><head>");
            tela.println("<meta http-equiv='Content-Type'content='text/html; charset=ISO-8859-1'>");
            tela.println("<title>Cria\347\343o de Servlets</title>");
            tela.println("</head><body>");
            tela.println("Obrigado, suas informa\347\365es foram gravadas com sucesso!");
            tela.println("<br><P>");
            tela.println((new StringBuilder("<b> Nome       : </b>")).append(nome).append("<br>").toString());
            tela.println((new StringBuilder("<b> Sexo       : </b>")).append(sexo).append("<br>").toString());
            tela.println((new StringBuilder("<b> Profissao  : </b>")).append(profissao).append("<br>").toString());
            tela.println((new StringBuilder("<b> \301reas de interesse  : </b>")).append(areas).append("<br>").toString());
            tela.println("</body></html>");
        }
        catch(IOException erro1)
        {
            try
            {
                PrintStream tela = new PrintStream(res.getOutputStream());
                tela.println("<html><body>");
                tela.println("Erro! N\343o foi poss\355vel receber os dados enviados");
                tela.println("<br><p>Tente novamente mais tarde");
                tela.println("</body></html>");
            }
            catch(IOException ioexception) { }
        }
    }
}
