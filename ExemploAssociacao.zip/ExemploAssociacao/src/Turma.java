
public class Turma {

	private String codigo;
	
	
	public Turma(){
		
	}


	public String getCodigo() {
		return codigo;
	}


	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
	
	
	
}
