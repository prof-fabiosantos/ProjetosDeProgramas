
public class TestarRadioRelogio {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		RadioRelogio radioRelogioLG = new RadioRelogio();
		radioRelogioLG.ajustarHorario("17:00h");
		radioRelogioLG.mostrarHorario();
		
		RadioRelogio radioRelogioSony = new RadioRelogio();
		radioRelogioSony.ajustarHorario("17:18");
		radioRelogioSony .sintonizarFrequencia("104,3");
		radioRelogioSony.mostrarHorario();
		radioRelogioSony.mostrarFrequencia();

	}

}
