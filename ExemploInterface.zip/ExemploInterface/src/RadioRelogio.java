
public class RadioRelogio implements Relogio, Radio{

	String horario;
	String frequencia;
	
	@Override
	public void ajustarHorario(String horario) {
		// TODO Auto-generated method stub
		
	this.horario = horario;	
	}

	@Override
	public void mostrarHorario() {
		// TODO Auto-generated method stub
		
		System.out.println("O horario atual e: "+horario);
		
	}

	@Override
	public void sintonizarFrequencia(String frequencia) {
		// TODO Auto-generated method stub
		
		this.frequencia = frequencia;
		
	}

	@Override
	public void mostrarFrequencia() {
		// TODO Auto-generated method stub
		
		System.out.println("A frequencia do radio e:"+frequencia);
		
	}
	
	

}
