
public interface Radio {
	
	public void sintonizarFrequencia(String frequencia);
	
	public void mostrarFrequencia();

}
