
public interface Relogio {
	
	public void ajustarHorario(String horario);
	
	public void mostrarHorario();

}
