
public class Principal {

	public static void mostrarBonificacao(Funcionario funcionario){
		System.out.println("Nome Funcionario: "+funcionario.getNome());
		System.out.println(String.format("Bonificacao: R$ %,.2f ",funcionario.getBonificacao()));
		System.out.println("============================================");
		
	}
	
	public static void main(String[] arg){ 
			
		
        Funcionario[] funcionarios = new Funcionario[2];
        
        //array para dois funcionarios
        funcionarios[0] = new Engenheiro("Ronaldo", 3000, "12345687000AB");  
               
        //Isso � correto, j� que Engenheiro �-um Funcionario  
        funcionarios[1] = new Motorista("Adriano",2012,"0001200230090");  
                
        
 		//Isso � correto, j� que Motorista �-um Funcionario          
        for(Funcionario func:funcionarios){   
            if(func instanceof Engenheiro){  
                Engenheiro  e = (Engenheiro) func;
                System.out.println("Nome Engenheiro: "+e.getNome());  
                System.out.println("CREA:"+e.getCrea());  
            }else{
            	Motorista m = (Motorista) func;
            	System.out.println("Nome Motorista: "+m.getNome());
                System.out.println("CNH: "+m.getCnh());  
            }  
              
            System.out.println();  
        }  
        
        Funcionario funcionario = new Funcionario("Jose", 1000);
		mostrarBonificacao(funcionario);        
        
    }  	
	
}
