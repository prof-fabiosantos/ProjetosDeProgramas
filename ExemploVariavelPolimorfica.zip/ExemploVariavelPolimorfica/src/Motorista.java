
public class Motorista extends Funcionario {

	private String cnh;
	
	public Motorista(String nome, float salario, String cnh) {
		super(nome, salario);
		this.cnh = cnh;
	}

	public String getCnh() {
		return cnh;
	}

	public void setCnh(String cnh) {
		this.cnh = cnh;
	}

	@Override
	public float getBonificacao() {
		// TODO Auto-generated method stub
		return super.getSalario()*0.15f;
	}
	
	

}
